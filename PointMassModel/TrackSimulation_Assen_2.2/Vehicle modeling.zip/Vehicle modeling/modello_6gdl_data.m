clc
clear all

% Vehicle data
l = 2.5;  % length  [m]
b = 1;    % width  [m]
h = 0.5;  % heigth  [m]

% Front suspension
up_f_arm_l = 0.5;     % Upper front arm lenght [m]
low_f_arm_l = 0.5;    % Lower front arm lenght [m]
f_pist_l = 0.3;       % Piston lenght [m]
f_cil_l = 0.4;        % Cilinder lenght [m]
init_f_pos = 0.07691; % Initial mutual position between cilinder and piston of rear shock absorbers [m]
k_f = 100000;         % Front shock absorbers stifness [N/m]
c_f = 1000;           % Front shock absorbers damping [Ns/m]

% Front hubs
f_hub_l = 0.25;       % Front hub lenght [m]

% Rear suspension
up_r_arm_l = 0.5;     % Upper rear arm lenght [m]
low_r_arm_l = 0.5;    % Lower rear arm lenght [m]
r_pist_l = 0.3;       % Piston lenght [m]
r_cil_l = 0.4;        % Cilinder lenght [m]
init_r_pos = 0.07691; % Initial mutual position between cilinder and piston of rear shock absorbers [m]
k_r = 100000;         % Rear shock absorbers stifness [N/m]
c_r = 1000;           % Rear shock absorbers damping [Ns/m]

% Rear hubs
r_hub_l = 0.25;       % Rear hub lenght [m]


