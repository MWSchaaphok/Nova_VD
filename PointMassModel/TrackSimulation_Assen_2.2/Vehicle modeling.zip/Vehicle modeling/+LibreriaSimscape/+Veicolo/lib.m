function lib ( libInfo )
libInfo.Name = 'Modelli Veicolo';
libInfo.Annotation = sprintf('Libreria modelli veicolo');
libInfo.ShowName = true;