function lib ( libInfo )
libInfo.Name = 'Modelli Ruota';
libInfo.Annotation = sprintf('Libreria ruota');
libInfo.ShowName = true;