function lib ( libInfo )
libInfo.Name = 'Modelli Multibody';
libInfo.Annotation = sprintf('Libreria modelli multibody');
libInfo.ShowName = true;